package ComplexSorts;

public interface QuickAndMergeSorts extends QuickSort, MergeSort {
}
